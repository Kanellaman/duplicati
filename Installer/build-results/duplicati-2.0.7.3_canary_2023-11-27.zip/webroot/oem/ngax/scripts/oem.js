/* Placeholder for OEM branding */
